restoreLogo('xiaomi-hat');
restoreBackground();