#!/bin/sh

/opt/etc/init.d/rc.unslung stop
umount -l /opt