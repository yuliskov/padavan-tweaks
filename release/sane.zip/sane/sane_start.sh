#!/bin/sh

if [ ! -d "/etc/storage/opt/etc" ] ; then
    mkdir -p -m 755 /etc/storage/opt/etc
    cp -dprf /usr/opt/etc/* /etc/storage/opt/etc
fi

mount --bind /usr/opt /opt
mount --bind /etc/storage/opt/etc /opt/etc

cp -dprf /opt/var/* /var
mount --bind /var /opt/var
mount --bind /tmp /opt/tmp
mkdir -p /tmp/admin
mount --bind /tmp/admin /opt/home/admin

export OLDPWD=/opt/home/admin
export TEMP=/opt/tmp
export TMP=/opt/tmp

/opt/etc/init.d/rc.unslung start

############### inetd.conf file create ###################
# if app not exist
    if [ ! -f /usr/sbin/inetd ]; then
            exit 0
    fi
    if [ -n "`pidof inetd`" ] ; then
        # stop daemon
            killall -q inetd
    fi
    Login=`nvram get http_username`
    touch /etc/inetd.conf
    echo "sane-port stream tcp nowait $Login /opt/sbin/saned saned" > /etc/inetd.conf
    /usr/sbin/inetd -R 30 -q 64 /etc/inetd.conf
##########################################################