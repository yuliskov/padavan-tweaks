restoreLogo('xiaomi-big');
restoreBackground();